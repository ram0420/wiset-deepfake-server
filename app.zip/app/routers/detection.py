# from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
# from fastapi.responses import StreamingResponse
# from sqlalchemy.orm import Session
# from app.dependencies import get_db, get_current_user
# from app.schemas.detection import (
#     DetectionRunResponse,
#     DetectionResultResponse,
#     DetectionResultData,
# )
# from app.services import detection_service

# import io
# import os
# import re
# import time
# import tempfile
# from threading import Lock
# from typing import Dict, Any, Optional, Tuple

# import torch
# import numpy as np
# from PIL import Image

# from app.detection_core.inference import run_freqnet_detection
# from app.detection_core.Freq_CAM import Freq_CAM_init
# from app.detection_core.inference import run_freqnet_detection_from_bytes

# router = APIRouter(prefix="/detections", tags=["detection"])

# # ===== 설정 =====
# MODEL_PATH = "./app/detection_core/0904_10epoch.pth"

# # # ===== 메모리 내 임시 이미지 저장소 (TTL) =====
# # # 구조: { token: {"orig": bytes, "gradcam": bytes, "exp": epoch_seconds} }
# # _IMAGE_STORE: Dict[str, Dict[str, Any]] = {}
# # _IMAGE_STORE_LOCK = Lock()
# # IMAGE_TTL_SECONDS = 10 * 60  # 10분 (필요시 조정)

# # def _purge_expired_tokens() -> None:
# #     now = time.time()
# #     with _IMAGE_STORE_LOCK:
# #         expired = [k for k, v in _IMAGE_STORE.items() if v.get("exp", 0) < now]
# #         for k in expired:
# #             _IMAGE_STORE.pop(k, None)

# # def _put_images_to_store(orig_png: bytes, cam_png: bytes) -> str:
# #     from uuid import uuid4
# #     token = uuid4().hex
# #     with _IMAGE_STORE_LOCK:
# #         _IMAGE_STORE[token] = {
# #             "orig": orig_png,
# #             "gradcam": cam_png,
# #             "exp": time.time() + IMAGE_TTL_SECONDS,
# #         }
# #     return token

# # def _get_image_from_store(token: str, kind: str) -> Optional[bytes]:
# #     _purge_expired_tokens()
# #     with _IMAGE_STORE_LOCK:
# #         entry = _IMAGE_STORE.get(token)
# #         if not entry:
# #             return None
# #         # 조회 시 TTL 연장(선택)
# #         entry["exp"] = time.time() + IMAGE_TTL_SECONDS
# #         if kind == "orig":
# #             return entry.get("orig")
# #         elif kind in ("gradcam", "cam"):
# #             return entry.get("gradcam")
# #         return None

# # def _pil_to_png_bytes(img_pil: Image.Image) -> bytes:
# #     buf = io.BytesIO()
# #     img_pil.save(buf, format="PNG")
# #     return buf.getvalue()

# # ===== 메모리 내 임시 이미지 저장소 (TTL + CAP) =====
# _IMAGE_STORE: Dict[str, Dict[str, Any]] = {}
# _IMAGE_STORE_LOCK = Lock()
# IMAGE_TTL_SECONDS = 2 * 60   # 2분 (필요시 조정)
# MAX_IMAGE_ITEMS   = 12       # 동시에 보관할 최대 결과 수

# def _purge_expired_tokens() -> None:
#     now = time.time()
#     with _IMAGE_STORE_LOCK:
#         expired = [k for k, v in _IMAGE_STORE.items() if v.get("exp", 0) < now]
#         for k in expired:
#             _IMAGE_STORE.pop(k, None)

# def _downscale_png(png_bytes: bytes, max_side: int = 1024) -> bytes:
#     try:
#         img = Image.open(io.BytesIO(png_bytes)).convert("RGB")
#         w, h = img.size
#         if max(w, h) > max_side:
#             if w >= h:
#                 new_w = max_side
#                 new_h = int(h * (max_side / w))
#             else:
#                 new_h = max_side
#                 new_w = int(w * (max_side / h))
#             img = img.resize((new_w, new_h), Image.BICUBIC)
#         buf = io.BytesIO()
#         img.save(buf, format="PNG", optimize=True)
#         return buf.getvalue()
#     except Exception:
#         return png_bytes  # 실패 시 원본 유지

# def _evict_if_needed():
#     # CAP 초과 시 가장 오래된 항목부터 제거
#     if len(_IMAGE_STORE) <= MAX_IMAGE_ITEMS:
#         return
#     # created(ts) 기준 정렬
#     victims = sorted(_IMAGE_STORE.items(), key=lambda kv: kv[1].get("ts", 0))
#     for k, _ in victims[: max(1, len(_IMAGE_STORE) - MAX_IMAGE_ITEMS)]:
#         _IMAGE_STORE.pop(k, None)

# def _put_images_to_store(orig_png: bytes, cam_png: bytes) -> str:
#     from uuid import uuid4
#     token = uuid4().hex
#     with _IMAGE_STORE_LOCK:
#         _purge_expired_tokens()
#         _evict_if_needed()
#         _IMAGE_STORE[token] = {
#             "orig": _downscale_png(orig_png),
#             "gradcam": _downscale_png(cam_png),
#             "exp": time.time() + IMAGE_TTL_SECONDS,
#             "ts": time.time(),
#         }
#     return token

# def _get_image_from_store(token: str, kind: str) -> Optional[bytes]:
#     _purge_expired_tokens()
#     with _IMAGE_STORE_LOCK:
#         entry = _IMAGE_STORE.get(token)
#         if not entry:
#             return None
#         # 조회 시 TTL 연장하지 않음(메모리 체류 최소화)
#         return entry.get("orig" if kind == "orig" else "gradcam")

# def _pil_to_png_bytes(img_pil: Image.Image) -> bytes:
#     buf = io.BytesIO()
#     img_pil.save(buf, format="PNG")
#     return buf.getvalue()

# # ===== 코어: 디스크 영구 저장 없이 추론 수행 =====
# async def _predict_deepfake_freqnet_no_persist(upload_file: UploadFile) -> Tuple[float, bool, bytes, bytes]:
#     """
#     디스크에 영구 저장하지 않고:
#     - 업로드 이미지를 메모리에서 PNG 정규화
#     - Windows 호환을 위해 닫힌 임시파일 경로(tmp_path)를 만들고 여기에만 잠시 기록
#     - 모델 추론 및 Grad-CAM 생성
#     - 임시파일 즉시 삭제
#     - 원본/Grad-CAM을 PNG 바이트로 반환
#     """
#     # 업로드 읽기
#     raw = await upload_file.read()
#     if not raw:
#         raise HTTPException(status_code=400, detail="빈 파일입니다.")

#     # 원본을 PIL로 파싱 (유효성 체크 겸 RGB 변환)
#     try:
#         orig_img = Image.open(io.BytesIO(raw)).convert("RGB")
#     except Exception:
#         raise HTTPException(status_code=415, detail="유효한 이미지 파일이 아닙니다.")

#     # 메모리에서 PNG 바이트로 정규화
#     orig_png = _pil_to_png_bytes(orig_img)

#     tmp_path = None
#     try:
#         # Windows: NamedTemporaryFile(delete=False) 후 수동 삭제
#         with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
#             tmp_path = tmp.name
#         with open(tmp_path, "wb") as f:
#             f.write(orig_png)

#         # ---- 모델 추론 (기존 함수가 image_path를 받으므로 임시 경로 사용) ----
#         # prediction, result = run_freqnet_detection(
#         #     model_path=MODEL_PATH,
#         #     image_path=tmp_path,
#         #     cuda=torch.cuda.is_available()
#         # )
#         # fake_confidence: float = float(result[1])
#         # is_fake: bool = (prediction == 1)
#         pred, scores = run_freqnet_detection_from_bytes(
#             model_path=MODEL_PATH,
#             img_bytes=orig_png,
#             cuda=torch.cuda.is_available()
#         )
#         is_fake = (pred == 1)
#         fake_confidence = float(scores[1])

#         # ---- Grad-CAM 생성 ----
#         cam_array = Freq_CAM_init(image_save_path=tmp_path, model_path=MODEL_PATH)
#         if isinstance(cam_array, Image.Image):
#             cam_img = cam_array
#         else:
#             cam_img = Image.fromarray(np.asarray(cam_array))
#         cam_png = _pil_to_png_bytes(cam_img)

#         return fake_confidence, is_fake, orig_png, cam_png

#     finally:
#         # 임시파일 제거 (영구 저장 방지)
#         if tmp_path and os.path.exists(tmp_path):
#             try:
#                 os.remove(tmp_path)
#             except Exception:
#                 pass

# # ===== 라우팅 =====

# @router.post("/create", status_code=201)
# def create_detection_session_endpoint(
#     db: Session = Depends(get_db),
#     user=Depends(get_current_user),
# ):
#     """
#     새로운 탐지 세션 생성
#     """
#     session = detection_service.create_detection_session(db=db, user_id=user.id)
#     return {"detectionId": session.id}

# @router.post("/{detectionId}/run", response_model=DetectionRunResponse, status_code=202)
# async def run_detection(
#     detectionId: str,
#     image: UploadFile = File(None),
#     file: UploadFile = File(None),  # 프런트가 'file' 필드명을 쓰는 경우 호환
#     db: Session = Depends(get_db),
#     user=Depends(get_current_user),
# ):
#     """
#     탐지 수행 (디스크 미저장) 및 결과 저장
#     - 원본/Grad-CAM 이미지는 메모리 캐시에 TTL로 보관
#     - DB details에는 token만 기록 (파일명 저장 안 함)
#     """
#     # 세션 확인
#     session = detection_service.get_detection_session(db, detectionId, user.id)
#     if not session:
#         raise HTTPException(status_code=404, detail="탐지 세션을 찾을 수 없습니다.")
#     if getattr(session, "status", None) == "completed":
#         raise HTTPException(status_code=409, detail="이미 탐지가 완료된 세션입니다.")

#     upload = image or file
#     if not upload:
#         raise HTTPException(status_code=400, detail="이미지 파일이 필요합니다. (form field: image)")

#     try:
#         fake_confidence, is_fake, orig_png, cam_png = await _predict_deepfake_freqnet_no_persist(upload)
#     except HTTPException:
#         raise
#     except Exception as e:
#         # 내부 예외는 500으로 래핑
#         print(f"[run_detection] error for {detectionId}: {e}")
#         raise HTTPException(status_code=500, detail="탐지 처리 중 오류가 발생했습니다.")

#     # 메모리 캐시에 저장하고 토큰 발급
#     token = _put_images_to_store(orig_png, cam_png)

#     # DB에 token 저장
#     details = f"token={token}"
#     detection_service.create_detection_result(
#         db=db,
#         session_id=session.id,
#         is_deepfake=is_fake,
#         confidence=fake_confidence,
#         details=details
#     )
#     detection_service.mark_session_completed(db, session)
#     try:
#         db.commit()
#     except Exception:
#         db.rollback()
#         raise

#     # 응답
#     return DetectionRunResponse(
#         detectionId=session.id,
#         message="탐지 요청이 정상적으로 접수되었습니다.",
#         estimatedTime=0
#     )

# @router.get("/result/{detectionId}", response_model=DetectionResultResponse)
# def get_detection_result(
#     detectionId: str,
#     db: Session = Depends(get_db),
#     user=Depends(get_current_user)
# ):
#     """
#     탐지 결과 + 이미지 URL 반환
#     - details에 token=xxxx 저장 → 동적 이미지 엔드포인트 URL 생성
#     """
#     session = detection_service.get_detection_session(db, detectionId, user.id)
#     if not session:
#         raise HTTPException(status_code=404, detail="탐지 세션을 찾을 수 없습니다.")

#     result = detection_service.get_detection_result(db, detectionId)
#     if not result:
#         # 기존 클라이언트가 폴링을 404 기준으로 구현했다면 유지
#         raise HTTPException(status_code=404, detail="탐지 결과를 찾을 수 없습니다.")

#     token = None
#     if result.details:
#         m = re.search(r"token=([a-f0-9]+)", result.details)
#         token = m.group(1) if m else None

#     image_url = f"/detections/image?kind=orig&t={token}" if token else None
#     gradcam_url = f"/detections/image?kind=gradcam&t={token}" if token else None

#     return DetectionResultResponse(
#         detectionId=session.id if hasattr(session, "id") else detectionId,
#         result=DetectionResultData(
#             isDeepfake=bool(result.is_deepfake),
#             confidence=float(result.confidence),
#             imageUrl=image_url,
#             gradcamUrl=gradcam_url,
#             details=result.details
#         )
#     )

# @router.get("/image")
# def get_image(kind: str, t: str):
#     """
#     메모리에 있는 PNG 이미지를 스트리밍 반환.
#     디스크 고정 저장 없이 동작.
#     """
#     if kind not in ("orig", "gradcam"):
#         raise HTTPException(status_code=400, detail="kind must be 'orig' or 'gradcam'")

#     data = _get_image_from_store(t, kind)
#     if not data:
#         # TTL 만료/토큰 없음 → 404
#         raise HTTPException(status_code=404, detail="이미지가 만료되었거나 토큰이 유효하지 않습니다.")

#     return StreamingResponse(
#         io.BytesIO(data),
#         media_type="image/png",
#         headers={
#             "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
#             "Pragma": "no-cache",
#             "Expires": "0",
#             "Content-Disposition": f'inline; filename="{kind}.png"',
#         },
#     )


from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.orm import Session, sessionmaker
from app.dependencies import get_db, get_current_user
from app.schemas.detection import (
    DetectionRunResponse,
    DetectionResultResponse,
    DetectionResultData,
)
from app.services import detection_service

import io
import os
import re
import time
import tempfile
from threading import Lock
from typing import Dict, Any, Optional, Tuple

import torch
import numpy as np
from PIL import Image

from app.detection_core.inference import run_freqnet_detection_from_bytes
from app.detection_core.Freq_CAM import Freq_CAM_init

router = APIRouter(prefix="/detections", tags=["detection"])

# ===== 설정 =====
MODEL_PATH = "./app/detection_core/0904_10epoch.pth"

# ===== 메모리 내 임시 이미지 저장소 (TTL + CAP) =====
_IMAGE_STORE: Dict[str, Dict[str, Any]] = {}
_IMAGE_STORE_LOCK = Lock()
IMAGE_TTL_SECONDS = 2 * 60   # 2분
MAX_IMAGE_ITEMS   = 12       # 동시에 보관할 최대 결과 수

def _purge_expired_tokens() -> None:
    now = time.time()
    with _IMAGE_STORE_LOCK:
        expired = [k for k, v in _IMAGE_STORE.items() if v.get("exp", 0) < now]
        for k in expired:
            _IMAGE_STORE.pop(k, None)

def _downscale_png(png_bytes: bytes, max_side: int = 1024) -> bytes:
    try:
        img = Image.open(io.BytesIO(png_bytes)).convert("RGB")
        w, h = img.size
        if max(w, h) > max_side:
            if w >= h:
                new_w = max_side
                new_h = int(h * (max_side / w))
            else:
                new_h = max_side
                new_w = int(w * (max_side / h))
            img = img.resize((new_w, new_h), Image.BICUBIC)
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        return buf.getvalue()
    except Exception:
        return png_bytes  # 실패 시 원본 유지

def _evict_if_needed():
    if len(_IMAGE_STORE) <= MAX_IMAGE_ITEMS:
        return
    victims = sorted(_IMAGE_STORE.items(), key=lambda kv: kv[1].get("ts", 0))
    for k, _ in victims[: max(1, len(_IMAGE_STORE) - MAX_IMAGE_ITEMS)]:
        _IMAGE_STORE.pop(k, None)

def _put_images_to_store(orig_png: bytes, cam_png: bytes) -> str:
    from uuid import uuid4
    token = uuid4().hex
    with _IMAGE_STORE_LOCK:
        _purge_expired_tokens()
        _evict_if_needed()
        _IMAGE_STORE[token] = {
            "orig": _downscale_png(orig_png),
            "gradcam": _downscale_png(cam_png),
            "exp": time.time() + IMAGE_TTL_SECONDS,
            "ts": time.time(),
        }
    return token

def _get_image_from_store(token: str, kind: str) -> Optional[bytes]:
    _purge_expired_tokens()
    with _IMAGE_STORE_LOCK:
        entry = _IMAGE_STORE.get(token)
        if not entry:
            return None
        return entry.get("orig" if kind == "orig" else "gradcam")

def _pil_to_png_bytes(img_pil: Image.Image) -> bytes:
    buf = io.BytesIO()
    img_pil.save(buf, format="PNG")
    return buf.getvalue()

# ===== 백그라운드 작업 =====
def _do_detection_in_bg(engine, detection_id: str, user_id: int, img_bytes: bytes):
    """
    백그라운드에서 추론+Grad-CAM 실행 후 결과/토큰 저장.
    - 현재 요청의 엔진(engine)으로 sessionmaker 생성 → 임포트 경로 문제 제거
    """
    from sqlalchemy.orm import Session as _Sess
    SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    db: _Sess = SessionLocal()
    try:
        print(f"[bg] start {detection_id}")

        session = detection_service.get_detection_session(db, detection_id, user_id)
        if not session:
            print(f"[bg] session not found {detection_id}")
            return

        # 1) 추론 (모델 싱글톤 사용)
        pred, scores = run_freqnet_detection_from_bytes(
            model_path=MODEL_PATH,
            img_bytes=img_bytes,
            cuda=torch.cuda.is_available()
        )
        is_fake = (pred == 1)
        fake_conf = float(scores[1])

        # 2) Grad-CAM (경로 요구 → 임시 디렉토리 사용 후 즉시 삭제)
        with tempfile.TemporaryDirectory() as td:
            tmp_path = os.path.join(td, "in.png")
            Image.open(io.BytesIO(img_bytes)).convert("RGB").save(tmp_path, "PNG")
            cam_arr = Freq_CAM_init(image_save_path=tmp_path, model_path=MODEL_PATH)
            cam_img = cam_arr if isinstance(cam_arr, Image.Image) else Image.fromarray(np.asarray(cam_arr))
            cam_png = _pil_to_png_bytes(cam_img)

        # 3) 토큰 발급 (원본도 PNG 정규화)
        orig_png = _pil_to_png_bytes(Image.open(io.BytesIO(img_bytes)).convert("RGB"))
        token = _put_images_to_store(orig_png, cam_png)

        # 4) DB 저장 → 완료
        detection_service.create_detection_result(
            db=db,
            session_id=session.id,
            is_deepfake=is_fake,
            confidence=fake_conf,
            details=f"token={token}"
        )
        detection_service.mark_session_completed(db, session)
        db.commit()

        print(f"[bg] done {detection_id} is_fake={is_fake} conf={fake_conf:.3f}")
    except Exception as e:
        db.rollback()
        print(f"[bg] detection failed for {detection_id}: {e}")
    finally:
        db.close()

# ===== 라우팅 =====
@router.post("/create", status_code=201)
def create_detection_session_endpoint(
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    session = detection_service.create_detection_session(db=db, user_id=user.id)
    return {"detectionId": session.id}

@router.post("/{detectionId}/run", response_model=DetectionRunResponse, status_code=202)
async def run_detection(
    detectionId: str,
    background: BackgroundTasks,
    image: UploadFile = File(None),
    file: UploadFile = File(None),  # 프런트가 'file' 필드명을 쓰는 경우 호환
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    print(f"[run] HIT detectionId={detectionId}")
    session = detection_service.get_detection_session(db, detectionId, user.id)
    if not session:
        raise HTTPException(status_code=404, detail="탐지 세션을 찾을 수 없습니다.")

    upload = image or file
    if not upload:
        raise HTTPException(status_code=400, detail="이미지 파일이 필요합니다. (form field: image 또는 file)")

    data = await upload.read()
    if not data:
        raise HTTPException(status_code=400, detail="빈 파일입니다.")
    print(f"[run] got file size={len(data)} bytes, ctype={upload.content_type}")

    # 현재 요청의 엔진을 백그라운드에 전달
    engine = db.get_bind()
    background.add_task(_do_detection_in_bg, engine, detectionId, user.id, data)

    # 즉시 202 반환 → 프론트는 result 폴링
    return DetectionRunResponse(
        detectionId=detectionId,
        message="processing",
        estimatedTime=5
    )

@router.get("/result/{detectionId}", response_model=DetectionResultResponse)
def get_detection_result(
    detectionId: str,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    session = detection_service.get_detection_session(db, detectionId, user.id)
    if not session:
        raise HTTPException(status_code=404, detail="탐지 세션을 찾을 수 없습니다.")

    result = detection_service.get_detection_result(db, detectionId)
    if not result:
        # 처리중이면 202로 → 프론트 로딩 유지/폴링
        return JSONResponse(
            status_code=202,
            content={"detectionId": detectionId, "result": None, "message": "processing"}
        )

    token = None
    if result.details:
        m = re.search(r"token=([a-f0-9]+)", result.details)
        token = m.group(1) if m else None

    image_url = f"/detections/image?kind=orig&t={token}" if token else None
    gradcam_url = f"/detections/image?kind=gradcam&t={token}" if token else None

    return DetectionResultResponse(
        detectionId=detectionId,
        result=DetectionResultData(
            isDeepfake=bool(result.is_deepfake),
            confidence=float(result.confidence),
            imageUrl=image_url,
            gradcamUrl=gradcam_url,
            details=result.details
        )
    )

@router.get("/image")
def get_image(kind: str, t: str):
    if kind not in ("orig", "gradcam"):
        raise HTTPException(status_code=400, detail="kind must be 'orig' or 'gradcam'")
    data = _get_image_from_store(t, kind)
    if not data:
        raise HTTPException(status_code=404, detail="이미지가 만료되었거나 토큰이 유효하지 않습니다.")
    return StreamingResponse(
        io.BytesIO(data),
        media_type="image/png",
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
            "Content-Disposition": f'inline; filename="{kind}.png"',
        },
    )
