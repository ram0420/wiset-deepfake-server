
# import uuid
# from sqlalchemy.orm import Session
# from fastapi import HTTPException
# from passlib.context import CryptContext
# from app.models import User, UserProfile, School
# from app.utils.auth import create_access_token

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# def get_password_hash(password: str) -> str:
#     return pwd_context.hash(password)

# def verify_password(plain: str, hashed: str) -> bool:
#     return pwd_context.verify(plain, hashed)

# def authenticate_user(db: Session, login_id: str, password: str):
#     user = db.query(User).filter(User.user_id == login_id).first()
#     if not user or not verify_password(password, user.password_hash):
#         return None
#     return user

# # def register_user(db: Session, username: str, password: str, email: str,
# #                   school_code: str, gender: str, phone: str, login_id: str):
    
# #     if db.query(User).filter(User.user_id == login_id).first():
# #         raise ValueError("이미 사용 중인 아이디입니다.")

# #     user_id = str(uuid.uuid4())
# #     hashed_pw = get_password_hash(password)

# #     user = User(id=user_id, user_id=login_id, email=email, password_hash=hashed_pw, phone=phone)
# #     db.add(user)

# #     # School 코드로 school_id 조회
# #     school = db.query(School).filter(School.code == school_code).first()
# #     # if not school:
# #     #     raise ValueError("유효하지 않은 학교 코드입니다.")

# #     profile = UserProfile(
# #         user_id=user_id,
# #         nickname=username,
# #         gender=gender,
# #         school_id=school.id,
# #         grade=1,
# #         class_num=1,
# #         score=0
# #     )
# #     db.add(profile)

# #     db.commit()
# #     db.refresh(user)

# #     return user

# def register_user(db: Session, username: str, password: str, email: str,
#                   school_code: str, gender: str, phone: str, login_id: str):
#     # if db.query(User).filter(User.user_id == login_id).first():
#     #     raise ValueError("이미 사용 중인 아이디입니다.")

#     user_id = str(uuid.uuid4())
#     hashed_pw = get_password_hash(password)

#     user = User(id=user_id, user_id=login_id, email=email, password_hash=hashed_pw, phone=phone)
#     db.add(user)

#     # ✅ 학교 코드로 school, grade, class_num 파싱
#     # 예: "한국중0101" → "한국중", 01(1학년), 01(1반)
#     school_prefix = school_code[:-4]          # "한국중"
#     grade = int(school_code[-4:-2])           # "01" → 1
#     class_num = int(school_code[-2:])         # "01" → 1

#     school = db.query(School).filter(School.code == school_code).first()
#     if not school:
#         raise ValueError("유효하지 않은 학교 코드입니다.")

#     profile = UserProfile(
#         user_id=user_id,
#         nickname=username,
#         gender=gender,
#         school_id=school.id,
#         grade=grade,            # ✅ 파싱된 값
#         class_num=class_num,    # ✅ 파싱된 값
#         score=0
#     )
#     db.add(profile)

#     db.commit()
#     db.refresh(user)

#     return user


import uuid
from sqlalchemy.orm import Session
from fastapi import HTTPException
from passlib.context import CryptContext
from app.models import User, UserProfile, School
from app.utils.auth import create_access_token

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def authenticate_user(db: Session, login_id: str, password: str):
    user = db.query(User).filter(User.user_id == login_id).first()
    if not user or not verify_password(password, user.password_hash):
        return None
    return user


def register_user(db: Session, username: str, password: str, email: str,
                  school_code: str, gender: str, phone: str, login_id: str):
    if db.query(User).filter(User.user_id == login_id).first():
        raise ValueError("이미 사용 중인 아이디입니다.")

    user_id = str(uuid.uuid4())
    hashed_pw = get_password_hash(password)

    user = User(
        id=user_id,
        user_id=login_id,
        email=email,
        password_hash=hashed_pw,
        phone=phone
    )
    db.add(user)

    # 학교 조회
    school = db.query(School).filter(School.code == school_code).first()
    if not school:
        raise ValueError("유효하지 않은 학교 코드입니다.")

    # 학교 코드에서 학년/반 추출 (예: "한국중0101" → 01, 01)
    grade = int(school_code[-4:-2])
    class_num = int(school_code[-2:])

    profile = UserProfile(
        user_id=user_id,
        nickname=username,
        gender=gender,
        school_id=school.id,
        grade=grade,
        class_num=class_num,
        score=0
    )
    db.add(profile)

    db.commit()
    db.refresh(user)

    return user
